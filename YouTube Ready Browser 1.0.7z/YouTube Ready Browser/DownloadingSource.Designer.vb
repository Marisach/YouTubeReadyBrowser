﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DownloadingSource
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!)
        Me.Label1.Location = New System.Drawing.Point(213, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(424, 45)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "リソースをダウンロードしましたか？"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!)
        Me.Label2.Location = New System.Drawing.Point(193, 142)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(487, 45)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "終わった場合は、終了をクリックします"
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Yu Gothic UI Semibold", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Button1.Location = New System.Drawing.Point(301, 289)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(225, 72)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "終了"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'DownloadingSource
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 457)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.Name = "DownloadingSource"
        Me.Text = "リソースのダウンロード"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Button1 As Button
End Class
