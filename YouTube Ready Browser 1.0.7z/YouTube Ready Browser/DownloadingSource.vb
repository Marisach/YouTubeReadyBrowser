﻿Public Class DownloadingSource
    Private Sub DownloadingSource_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        My.Computer.Network.DownloadFile(
    "https://msedge.sf.dl.delivery.mp.microsoft.com/filestreamingservice/files/024248e2-46ec-4b74-8d5a-4ee330245c38/MicrosoftEdgeWebView2RuntimeInstallerX64.exe",
    "C:\Users\" & System.Environment.UserName & "\AppData\Local\temp\MicrosoftEdgeWebView2RuntimeInstallerX64.exe")

        My.Computer.Network.DownloadFile(
    "https://c2rsetup.officeapps.live.com/c2r/downloadEdge.aspx?platform=Default&source=EdgeInsiderPage&Channel=Canary&language=ja",
    "C:\Users\" & System.Environment.UserName & "\AppData\Local\temp\MicrosoftEdgeSetupCanary.exe")

        Process.Start("C:\Users\" & System.Environment.UserName & "\AppData\Local\temp\MicrosoftEdgeWebView2RuntimeInstallerX64.exe")
        Process.Start("C:\Users\" & System.Environment.UserName & "\AppData\Local\temp\MicrosoftEdgeSetupCanary.exe")
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        IO.File.Delete("C:\Users\" & System.Environment.UserName & "\AppData\Local\Temp\MicrosoftEdgeWebView2RuntimeInstallerX64.exe")
        IO.File.Delete("C:\Users\" & System.Environment.UserName & "\AppData\Local\Temp\MicrosoftEdgeMicrosoftEdgeSetupCanary.exe")
        Me.Close()
    End Sub
End Class