﻿Public Class Form1
    Private Sub リソースのダウンロードToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles リソースのダウンロードToolStripMenuItem.Click
        DownloadSource.Show()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub バージョン情報ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles バージョン情報ToolStripMenuItem.Click
        MessageBox.Show("YouTube Ready Browser version 94 for Windows
Used Microsoft(R) WebView2
Copyright 2005-2021 Nenetsu Corporation. All rights reversed.
Copyright 1985-2021 Microsoft Corporation. All rights reversed.")
    End Sub

    Private Sub 閉じるToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles 閉じるToolStripMenuItem.Click
        Environment.ExitCode = 1
        Application.Exit()
    End Sub
End Class
